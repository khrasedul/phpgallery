<?php require_once("temp-part/header.php"); ?>

<style>
     body{
       color: #fff;
        margin: 0;
        padding: 0;
        background-image:linear-gradient(rgba(0,0,0,0.4),rgba(0,0,0,0.4)) ,url("admin/img/bg.jpg");
        background-size:cover;
        background-repeat: no-repeat;
        background-position: ;
        width: 100%;
        height: 100%;
        /*height: calc(100%-100px);*/
      }
  .about{
    width:600px;
    margin: auto;
    margin-top: 10%;
    text-align: center;
  }
  .about img{
    height: 400px;
    width:400px;
    border-radius: 400px;
    border: 1px solid #ddd;
  }
  h1,h3{
    margin: 0;
  }
  h1{
    font-family: arial black;
    font-size: 50px;
    color: #ddd;
    margin-top:20px;
  }
  h3{
	font-size:30px;
    font-family: sans;
    margin-top: 5px;
  }
  a{
    color: yellow;
    padding: 10px 5px;
    font-size: 35px;
    text-decoration: none;
  }
</style>
<div class="about">
  <img src="admin/img/me.jpg">
  <h1>
    KH RASEDUL HASAN
  </h1>
  <h3>
    Founder RPS IT SOLUTION.
  </h3>
  <hr>
   <a href="#"><i class="fas fa-facebook"></i></a>
   <a href="#"><i class="fas fa-twitter"></i></a>
   <a href="#"><i class="fas fa-youtube"></i></a>
   <a href="#"><i class="fas fa-instagram"></i></a>
  <br>
  <br>
  __/Follow on github <a href="#">@Kh Rasedul</a>
</div>


<?php require_once("temp-part/footer.php"); ?>