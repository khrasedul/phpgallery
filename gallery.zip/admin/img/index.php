<html>
  <head>
    <title>Access Denied || PHP Self Gallery.</title>
    <style>
      body{
        background-color: #ddd;
      }
      .main{
        margin: auto;
        width: 400px;
        color: red;
        margin-top: 40%;
        text-align: center;
        font-size: 80px;
      }
    </style>
  </head>
  <body>
    <div class="main">
	  You can't Explore This Path!
    </div>
  </body>
</html>